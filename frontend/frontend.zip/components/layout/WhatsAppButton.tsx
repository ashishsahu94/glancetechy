"use client";
// components/WhatsAppButton.tsx  -> layout.tsx mein <WhatsAppButton /> lagao
import { useEffect, useState } from "react";

// .env.local mein: NEXT_PUBLIC_WHATSAPP_NUMBER=+91 91988 59019  (91 + 10 digit, bina + ya space ke)
const NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "+919198859019";
const MESSAGE = "Hi! I'd like to know more about your services.";
const APPEAR_AFTER_MS = 2200; // loader ke baad aaye

export default function WhatsAppButton() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), APPEAR_AFTER_MS);
    return () => clearTimeout(t);
  }, []);

  return (
    <a
      href={`https://wa.me/${NUMBER}?text=${encodeURIComponent(MESSAGE)}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      style={{ marginBottom: "env(safe-area-inset-bottom)" }}
      className={`group fixed bottom-5 right-5 z-50 flex items-center rounded-full bg-whatsapp p-3.5 text-white shadow-lg shadow-black/20 transition duration-500 ease-out hover:shadow-xl focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-whatsapp motion-reduce:transition-none sm:bottom-6 sm:right-6 ${
        visible ? "translate-y-0 scale-100 opacity-100" : "pointer-events-none translate-y-6 scale-75 opacity-0"
      }`}
    >
      {/* Soft pulse ring */}
      <span
        aria-hidden="true"
        className="absolute inset-0 -z-10 animate-ping rounded-full bg-whatsapp opacity-40 [animation-duration:2.6s] motion-reduce:hidden"
      />

      {/* Label: hover/focus pe left ki taraf khulta hai */}
      <span className="max-w-0 overflow-hidden whitespace-nowrap text-sm font-medium opacity-0 transition-all duration-300 group-hover:max-w-[140px] group-hover:pr-3 group-hover:opacity-100 group-focus-visible:max-w-[140px] group-focus-visible:pr-3 group-focus-visible:opacity-100 motion-reduce:transition-none">
        Chat with us
      </span>

      <svg viewBox="0 0 24 24" className="h-7 w-7 shrink-0 transition-transform duration-300 group-hover:scale-110 motion-reduce:transition-none" fill="currentColor" aria-hidden="true">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
      </svg>
    </a>
  );
}